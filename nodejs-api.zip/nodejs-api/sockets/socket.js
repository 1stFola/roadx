
const { userConnectStatus } = require('../controllers/customer');
const { redisSet } = require('../helpers/redis');
const cookieParser = require('cookie-parser');
const config = require('../config/constant');
const passport = require('passport')

function auth (socket, next) {

    return new Promise((resolve, reject) => {
        cookieParser()(socket.request, socket.request.res, () => {});
        passport.authenticate('jwt', {session: false}, function (error, decryptToken, jwtError) {
            if(!error && !jwtError && decryptToken) {
                resolve(decryptToken)
            } else {
                reject(error);
            }
        })(socket.request, socket.request.res);
    });
}


module.exports = (io, client) => {

    io.on('connection', function (client) {
            console.log("connection");

        auth(client).then((user) => {

            console.log("Cliente connection");
            console.log(user);

            client.join(user.id);
            redisSet(user.id, true);
            userConnectStatus(user.id, true);
            client.broadcast.emit('online_status', { customer_id : user.id, online: true });

            require('./rideTracker')(io, client, user);
            require('./movement')(io, client, user);



//            function sendHeartbeat(){
//                setTimeout(sendHeartbeat, 8000);
//                io.sockets.emit('ping', { beat : 1 });
//            }
//
//            io.sockets.on('connection', function (socket) {
//                socket.on('pong', function(data){
//                    console.log("Pong received from client");
//                });
//            });
//
//            setTimeout(sendHeartbeat, 8000);

            client.on('disconnect', () => {

                console.log("Cliente Desconectado");

                client.leave(user.id);
                redisSet(user.id, false);
                userConnectStatus(user.id, false);

                client.broadcast.emit('online_status', { customer_id : user.id, online: false });
            });
        }).catch(e => {
            console.log(e)
            client.disconnect();
        })



    });


}
