const { saveMessage, updateMessage, updateMessageRead } = require('../controllers/customer');
const { redisGet, redisArraySet, redisArrayGet } = require('../helpers/redis');
//const { sendToUser } = require('../helpers/fcm');


module.exports = (io, client, user, call) => {

    client.on('current_position', function(array){
        if (array != null) {
            if (array.isDriver != null && array.isDriver) {
                /*
                Need to send to subscribed passengers
                */
                io.sockets.emit('driver_update', array);
            } else {
                /*
                Need to send to subscribed drivers
                */
                io.sockets.emit('passenger_update', array);
            }
            redisArraySet("location:"+user_id, array);
        }
    });

    client.on('track_user', function(array){
        if (array != null) {
            if (array.status === 'join') {
                socket.join(array.user_id);
                redisArrayGet("location:"+array.user_id).then((array)=> {
                    io.to(array.user_id).emit('location_update', array);
                });
            } else {
                socket.leave(array.user_id);
            }
        }
    });


}