//const { getUserBusiness } = require('../controllers/business');
const { getAllFriends } = require('../controllers/customer');
//const { sendToUser } = require('../helpers/fcm');
const cookieParser = require('cookie-parser');


module.exports = (client, pattern, channel, array) => {

    if(channel == "events.update_ride_tracker_status"){
        var rideTracker = JSON.parse(array);

        /* Sent to Driver */
        io.to(rideTracker.driverRequest.user_id).emit('ride_tracker_status', rideTracker);

//        sendToUser({
//            token : "",
//            collapse_key : "",
//            notification: {
//                title: 'Title of your push notification',
//                body: 'Body of your push notification'
//            },
//            data: {
//                my_key: 'my value',
//                my_another_key: 'my another value'
//            }
//        });
     }else if(channel == "events.update_passenger_ride_tracker_status"){
        /* Sent to passenger */

        if(array.driver_status == "Approved"){

            io.to(array.user_id).emit('passenger_approved_update', array);

            var array = [];
            ass_array.push(array)
            io.to(array.driverRequest.user_id).emit('driver_approved_update', ass_array);

            sendToUser({
                token : "",
                collapse_key : "",
                notification: {
                    title: 'Title of your push notification',
                    body: 'Body of your push notification'
                },
                data: {
                    my_key: 'my value',
                    my_another_key: 'my another value'
                }
            });
        }


     }
}

async function sendNotificationFriendRequest () {
    sendToUser({
            token : "",
            collapse_key : "",
            notification: {
                title: 'Title of your push notification',
                body: 'Body of your push notification'
            },
            data: {
                my_key: 'my value',
                my_another_key: 'my another value'
            }
        });
}

async function sendNotificationCreateFeed () {
    sendToUser({
            token : "",
            collapse_key : "",
            notification: {
                title: 'Title of your push notification',
                body: 'Body of your push notification'
            },
            data: {
                my_key: 'my value',
                my_another_key: 'my another value'
            }
        });
}

async function sendNotificationCreateBusiness () {
        sendToUser({
            token : "",
            collapse_key : "",
            notification: {
                title: 'Title of your push notification',
                body: 'Body of your push notification'
            },
            data: {
                my_key: 'my value',
                my_another_key: 'my another value'
            }
        });
}

