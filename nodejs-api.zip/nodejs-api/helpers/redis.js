var redis = require('redis');
var client = redis.createClient();

//client.on('connect', function() {
//    console.log('connected');
//});

module.exports = {

   redisGet: (user_id, call) => {
       var client = redis.createClient();
       client.get(user_id, function(err, reply) {
             call(reply);
       });
   },
   redisSet: (user_id, status) => {
       var client = redis.createClient();
       client.set(user_id, status);
   },
   redisArrayGet: (name, call) => {
       var client = redis.createClient();
       client.get(user_id, function(err, reply) {
            const redisValue = JSON.parse(obj);
            call(redisValue);
       });
   },
   redisArraySet: (name, status) => {
       var client = redis.createClient();
       const redisValue = JSON.stringify(obj);
       client.set(name, redisValue);
   }
}

