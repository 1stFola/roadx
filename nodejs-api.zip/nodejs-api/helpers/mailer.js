const mailer = require('nodemailer')
require('dotenv').config()
var template_properties = require("../helpers/template_properties");
var email_config = require("../helpers/email_config");
var nodemailer = require("nodemailer");
var path = require('path');
var ejs = require("ejs");

const transport = mailer.createTransport({
    host: process.env.MAIL_HOST,
    port: process.env.MAIL_PORT,
    secure: process.env.MAIL_PORT == 465,
    auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASS
    }
})

/**
 * Mailer Helper
 */
const Mailer = {

    sendMail (email, subject, message) {
        transport.sendMail({
            from: `"Turing Test" <${process.env.MAIL_USER}>`,
            to: email,
            subject: subject,
            html: message
        }).then(info => {
            console.log('Email sent: ', info.messageId)
        }).catch(err => {
            console.log('Could not send mail ', err)
        })
    },

    sendTemplate(mail) {
        var input = Object.assign( template_properties, mail.data);
        let transporter = nodemailer.createTransport(email_config);
        var parentDir = path.normalize(__dirname+"/");

        ejs.renderFile(parentDir + "../views/mail/"+ mail.template +".ejs", input , function (err, data) {
            if (err) {
                console.log(err);
                // log error
            } else {
                var mainOptions = {
                    from:  template_properties.from_email,
                    to: mail.to,
                    subject: mail.subject,
                    html: data
                };
                console.log("html data ======================>", mainOptions.html);
                transporter.sendMail(mainOptions, function (err, info) {
                    if (err) {
                        console.log(err);
                    } else {
                        console.log('Message sent: ' + info.response);
                    }
                });
            }

        });
    }

}

module.exports = Mailer