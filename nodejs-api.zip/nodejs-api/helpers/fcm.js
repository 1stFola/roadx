var FCM = require('fcm-node')
//var serverKey = require('path/to/privatekey.json') //put the generated private key path here
var serverKey = "" //put the generated private key path here
var fcm = new FCM(serverKey)


module.exports = {

   sendToUser: (arr) => {
         var message = {
            to: arr.token,
            collapse_key: arr.collapse_key,
            notification: arr.notification,
            data: arr.data
        }
        fcm.send(message, function(err, response){
            if (err) {
                console.log("Something has gone wrong!")
            } else {
                console.log("Successfully sent with response: ", response)
            }
        });
   }
}

