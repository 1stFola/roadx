module.exports = {
    service: 'gmail',
    auth: {
        user: 'yemidada@gmail.com',
        pass: 'martinsdada123A!'
    }
}