module.exports = {
    from_email:'hello@maxhealth.com',
    Company_Name:'Acme Corp.',
    Company_Address:'1234 Street Rd.',
    Company_Zip:'Suite 1234',
    Product_Name: 'MaxHealth',
    login_url: '/users/login',
    reset_url: '/users/reset/',
    root_url: 'http://maxhealth.care',
    support_email: 'hello@maxhealth.care',
    help_url: '/help',
    current_year: '2019'
}