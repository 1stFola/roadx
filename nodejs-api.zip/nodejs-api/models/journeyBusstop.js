'use strict';
module.exports = (sequelize, DataTypes) => {
  const JourneyBusstop = sequelize.define('JourneyBusstop', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    position: DataTypes.INTEGER,
    journey_id: DataTypes.INTEGER,
    busstop_id: DataTypes.INTEGER,
  }, {
    engine: 'MYISAM',
    freezeTableName: true,
    tableName: 'journey_busstops',
    timestamps: false
  });
  JourneyBusstop.associate = function(models) {
    JourneyBusstop.belongsTo(models.Journey, {
      foreignKey: 'journey_id',
      through: 'id',
      as: 'journey'
    });
    JourneyBusstop.belongsTo(models.Busstop, {
      foreignKey: 'busstop_id',
      through: 'id',
      as: 'busstop'
    });
  };
  return JourneyBusstop;
};