'use strict';
module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    first_name: DataTypes.STRING,
    last_name: DataTypes.STRING,
    gender: DataTypes.STRING,
    phone: DataTypes.STRING,
    address: DataTypes.STRING,
    workplace: DataTypes.STRING,
    hasAc: DataTypes.BOOLEAN,
    interest: DataTypes.STRING,
    car_model: DataTypes.STRING,
    car_colour: DataTypes.STRING,
    number_plate: DataTypes.STRING,
    fcmToken: DataTypes.STRING,
    birth_date: DataTypes.DATE,
    image: DataTypes.STRING,
    work_email: DataTypes.STRING,
    confirm_work_email: DataTypes.STRING,
    activation_token: DataTypes.STRING,
    active: DataTypes.BOOLEAN,
    social_token: DataTypes.STRING,
    isOnline: DataTypes.BOOLEAN,
    email: {
      type: DataTypes.STRING,
      unique: true
    },
    password: DataTypes.STRING,
  }, {
    freezeTableName: true,
    tableName: 'Users',
    timestamps: false
  });
  User.associate = function(models) {
    // associations can be defined here
  };
  return User;
};
