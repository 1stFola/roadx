'use strict';
module.exports = (sequelize, DataTypes) => {
  const Journey = sequelize.define('Journey', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    start: DataTypes.STRING,
    destination: DataTypes.STRING,
    description: DataTypes.STRING,
    type: DataTypes.STRING,
    created_by: DataTypes.INTEGER,

  }, {
    engine: 'MYISAM',
    freezeTableName: true,
    tableName: 'journey',
    timestamps: false
  });
  Journey.associate = function(models) {
    // associations can be defined here
//    Journey.hasMany(models.Busstop, {
//      foreignKey: 'journey_id',
//      through: 'id',
//      as: 'journeyBusstop'
//    });
  };
  return Journey;
};