'use strict';
module.exports = (sequelize, DataTypes) => {
  const RideTracker = sequelize.define('RideTracker', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: DataTypes.INTEGER,
    driver_request_id: DataTypes.INTEGER,
    driver_status: DataTypes.STRING,
    passenger_request_id: DataTypes.INTEGER,
    passenger_status: DataTypes.STRING,
    distance: DataTypes.INTEGER,
    duration: DataTypes.STRING,
    category: DataTypes.STRING,
    cost: DataTypes.STRING,
  }, { 
    engine: 'MYISAM',
    freezeTableName: true,
    tableName: 'ride_tracker',
    timestamps: false
  });
  RideTracker.associate = function(models) {
    RideTracker.belongsTo(models.User, {
      foreignKey: 'user_id',
      through: 'id',
      as: 'user'
    });
    RideTracker.belongsTo(models.RideRequest, {
      foreignKey: 'driver_request_id',
      through: 'id',
      as: 'driverRequest'
    });
    RideTracker.belongsTo(models.RideRequest, {
      foreignKey: 'passenger_request_id',
      through: 'id',
      as: 'passengerRequest'
    });
  };
  return RideTracker;
};