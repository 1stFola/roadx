'use strict';
module.exports = (sequelize, DataTypes) => {
  const Busstop = sequelize.define('Busstop', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    longitude: DataTypes.DOUBLE,
    latitude: DataTypes.DOUBLE,
    address: DataTypes.STRING,
    place_id: DataTypes.STRING,
    formatted_address: DataTypes.STRING,

  }, {
    engine: 'MYISAM',
    freezeTableName: true,
    tableName: 'busstops',
    timestamps: false
  });
  Busstop.associate = function(models) {
    // associations can be defined here
  };
  return Busstop;
};