'use strict';
module.exports = (sequelize, DataTypes) => {
  const RideRequest = sequelize.define('RideRequest', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: DataTypes.INTEGER,
    journey_id: DataTypes.INTEGER,
    start_id: DataTypes.INTEGER,
    destination_id: DataTypes.INTEGER,
    driver: DataTypes.BOOLEAN,
    carType: DataTypes.STRING,
    status: DataTypes.ENUM("PENDING", "BOOKED"),
    created_at: DataTypes.DATE,
    updated_at: DataTypes.DATE,

  }, {
    freezeTableName: true,
    tableName: 'ride_request',
    timestamps: false
  });
  RideRequest.associate = function(models) {
    RideRequest.belongsTo(models.User, {
      foreignKey: 'user_id',
      through: 'id',
      as: 'user'
    });
    RideRequest.belongsTo(models.Busstop, {
      foreignKey: 'start_id',
      through: 'id',
      as: 'start'
    });
    RideRequest.belongsTo(models.Journey, {
      foreignKey: 'journey_id',
      through: 'id',
      as: 'journey'
    });
    RideRequest.belongsTo(models.Busstop, {
      foreignKey: 'destination_id',
      through: 'id',
      as: 'destination'
    });
  };
  return RideRequest;
};