const express = require('express');
const logger = require('morgan');
const bodyParser = require('body-parser');
const passport = require('passport')
const helmet = require('helmet')
const cors = require('cors')
const swaggerUi = require('swagger-ui-express')
const swaggerDoc = require('./swagger.json')

require('dotenv').config()

require('./helpers/passport')

//set up express
const app = express();

//log requests to the console
if (process.env.DEBUG) {
    app.use(logger('dev'));
}

//secuity
app.use(helmet())

//Parse incoming requests data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }))

app.use(cors())

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc))
//app.use('/api/v1', )

const routes = require('./routes');
/*app.get('*', (req, res) => res.status(200).send({
    message: "Welcome to my API"
}));*/
app.use('/', routes)
app.use(passport.initialize())
const session = require('express-session')

let RedisStore = require('connect-redis')(session)

//RedisStore = require("connect-redis")(express);


var  subscriber = require("redis").createClient();
//var  publisher = require("redis").createClient();
//var  sessionStore = require("redis").createClient();

app.use(
    session({
      store: new RedisStore({ client: subscriber }),
      secret: 'keyboard cat',
      resave: false,
    })
  )

subscriber.on("error", function (err) {
  console.log("Error " + err);
});

// Handle subscribers
channel = "events.*";
subscriber.psubscribe(channel);

subscriber.on("pmessage", function(pattern, channel, message) {
  require('./sockets/redis')(global.io.sockets, pattern, channel, message);
});



module.exports = app;