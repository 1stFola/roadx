const busstop = require('../controllers/busstop')
const auth = require('../helpers/auth')

module.exports = (router) => {
    router.get('/api/busstop/nearestBusstop', auth, busstop.nearestBusstop)
    router.get('/api/busstop/autoComplete', auth, busstop.autoComplete)
    router.get('/api/busstop/destinationPoint/:busstop_id', auth, busstop.destinationPoint)
//    router.get('/orders/shortDetail/:order_id', auth, busstop.getShortDetail)
}