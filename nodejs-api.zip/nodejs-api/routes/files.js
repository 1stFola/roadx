'use strict';

const filesRoute = require('express').Router();
const filesController = require('../controllers/filesController')

module.exports = (router) => {
    router.get('/api/file/:location/:filename', filesController.get_file)
    router.get('/api/file/:location/:sub_location/:filename', filesController.get_file_sub_location)
    router.post('/api/file/:location', filesController.upload.single('file'), filesController.create) //for general files
    router.post('/api/file/:location/:sub_location', filesController.upload.single('file'), filesController.create_sub_location); //for user avatars
}


