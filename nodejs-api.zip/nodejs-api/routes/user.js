const customer = require('../controllers/customer')
const authenticate = require('../helpers/auth')
const cache = require('apicache').middleware


module.exports = (router) => {
    router.put('/api/user', authenticate, customer.updateUser)
    router.get('/api/user', authenticate, cache('1 hour'), customer.getUser)
    router.post('/api/register', customer.register)
    router.post('/api/confirmAccount', customer.activeRegister)
    router.post('/api/login', customer.apiLogin)
    router.post('/api/socialLogin', customer.socialLogin)

    router.get('/api/password/create', customer.passwordCreate)
    router.get('/api/password/reset', customer.passwordReset)

}