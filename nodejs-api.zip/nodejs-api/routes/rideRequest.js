const rideRequest = require('../controllers/rideRequest')
const auth = require('../helpers/auth')

module.exports = (router) => {
    router.post('/api/rideRequest', auth, rideRequest.create)
    router.post('/api/rideRequest/getAvailableRide', auth, rideRequest.getAvailableRide)
}