const express = require('express')
const router = express.Router()

const busstopRoutes = require('./busstop')
const rideRequestRoutes = require('./rideRequest')
const rideTrackerRoutes = require('./rideTracker')
const userRoutes = require('./user')
const fileRoutes = require('./files')

const config = require('../config/constant');


fileRoutes(router)
busstopRoutes(router)
rideRequestRoutes(router)
rideTrackerRoutes(router)
userRoutes(router)

router.get('/', (req, res) => {
        console.log(config.root + 'views/index.html')
    return res.sendFile(config.root + 'views/index.html');
    return res.send({message: 'Welcome to Turing Test API'})
})

module.exports = router
