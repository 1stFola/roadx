const rideTracker = require('../controllers/rideTracker')
const cache = require('apicache').middleware
const auth = require('../helpers/auth')

module.exports = (router) => {
    router.post('/api/rideTracker', auth, rideTracker.create)
    router.put('/api/rideTracker/:rideTracker_id', auth, rideTracker.update)
    router.get('/api/rideTracker/:rideTracker_id', auth, rideTracker.get)
    router.delete('/api/rideTracker/:rideTracker_id', auth, rideTracker.delete)
}