const path = require('path');

module.exports = {
  // Root path of server
  root: path.normalize(__dirname + '/../'),
  rootFiles: path.normalize(__dirname + './../views/uploads-store'),

  apiVersion: 'v1',

  secretOrKey: 'jwt-secret-tradirect-yemi',

}