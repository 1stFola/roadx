const db = require('../models')
const RideRequest = db.sequelize.models.RideRequest
const User = db.sequelize.models.User
const JourneyBusstop = db.sequelize.models.JourneyBusstop
var  publisher = require("redis").createClient();



/**
 * Handles orders API requests
 */
const RideRequestController = {

    async create (req, res) {

        try {

            RideRequest.destroy({
                where: {
                    user_id : req.user.id,
                    status : "PENDING"
                }
            });
            var body = req.body;
            body.user_id = req.user.id;
            const user = await RideRequest.create(req.body);

//            publisher.publish('events.passenger_update', "user");
            return res.status(200).send(user)

        } catch (err) {
            console.log(err)
            return res.status(500).send(err)
        }
    },


    async getAvailableRide (req, res) {
        try {

            const pick_up = req.body.start_id;
            const destination = req.body.destination_id;
            const isDriver = req.body.driver;

            const starJourney = await JourneyBusstop.findAll({
                where: { busstop_id: pick_up }
            });

            const destinJourney = await JourneyBusstop.findAll({
                where: { busstop_id: destination }
            });

            let array = [];
            for(var i=0; i < starJourney.length; i++){
                for(var j=0; j < destinJourney.length; j++){
                    if(starJourney[i].journey_id == destinJourney[j].journey_id){
                        array.push(starJourney[i].journey_id);
                    }
                }
            }

            const rides = await RideRequest.findAll({
                    where: {
                        driver: isDriver,
                        journey_id : array,
                        status: "PENDING"
                    },
                include : [{
                    model: User , as: 'user',
                    attributes: ['id', 'first_name', 'last_name', 'image']
                }]

            });

            return res.send(rides);

        } catch (err) {
            return res.status(500).send(err)
        }
    },


}


module.exports = RideRequestController