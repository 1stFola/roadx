const db = require('../models')
const User = db.sequelize.models.User
const passport = require('passport')
const bcrypt = require('bcrypt')
const mailer = require('../helpers/mailer')
const pagination = require('../helpers/pagination')
const config = require('../config/constant');
const jwt = require('jsonwebtoken')

const validator = require('../validations/user')
const errorCodes = require('../helpers/error_codes').user
const Op = db.Sequelize.Op;
const saltRounds = 10;
const { customAlphabet } = require('nanoid');
const nanoid = customAlphabet('1234567890', 4)

//https://medium.com/swlh/server-side-pagination-in-node-js-with-sequelize-orm-and-mysql-73b0190e91fa
/**
 * Handles user API requests
 */
const UserController = {

    async userConnectStatus (user_id = '', isOnline) {
       try {
            console.log(isOnline)
            console.log(user_id)
            await User.update( { isOnline : isOnline }, { where: { id: user_id } });
       } catch(err) {
            console.log(err)
       }
    },
    async getConnectStatus (user_id = '') {
        return new Promise((resolve, reject) => {
            try {
                User.findOne({
                    attributes: ['isOnline'],
                    where: { id: user_id }
                }).then(user => {
                    resolve(user);
                })
            } catch(err) {
                console.log(err)
                reject(err);
            }
        });
    },


    /**
     * Handles user profile update
     * @param {*} req
     * @param {*} res
     */
    async updateUser (req, res) {

//        const { isValid, error } = await validator.validateUpdate(req.body, req.user)
//        if (!isValid) {
//            return res.status(400).json({error})
//        }

        try {
            const user = req.user;

            console.log(user)
            const body = req.body;

            body.password = user.password;
            body.email = user.email;

            await User.update( req.body, { where: { id: user.id } })
            return UserController.getUser(req, res)
        } catch (err) {
            console.log(err)
            return res.status(500).send(err)
        }
    },

    /**
     * Fetch logged in user profile
     * @param {*} req
     * @param {*} res
     */
    async getUser(req, res) {
        try {
             const userServer = req.user;

            const user = await User.findOne({
                where: { id: userServer.id }
            })
            user.password = undefined
            return res.status(200).send(user)
        } catch(err) {
            console.log(err)
            return res.status(500).send(err)
        }
    },

    /**
     * Handles user registration and automatic sign in
     * @param {*} req
     * @param {*} res
     * @param {*} next
     */
    async register (req, res, next) {
        //validate

        const { isValid, error } = await validator.validateRegister(req.body);
        if (!isValid) {
          return res.status(400).json({error})
        }



        try {


            const user = await User.findOne({
              where: { email: req.body.email,  }
            });

            const body = req.body
            const hashed = await bcrypt.hash(body.password, saltRounds)
            const data = {
                first_name: body.first_name,
                last_name: body.last_name,
                email: body.email,
                phone: body.phone,
                activation_token: nanoid(),
                active: false,
                password: hashed
            }
            if(user == null){
                const user = await User.create(data);
            }else{
                await User.update(data, { where: { id : user.id,  } });
            }

            let mail = {
                to: data.email,
                subject: 'Registered User',
                data: {first_name: data.first_name, email: data.email, activation_token : data.activation_token},
                template: "register"
            };
            mailer.sendTemplate(mail);


            return res.status(200).send({data : "A token has been sent to your email address"})

//            return __signin(req, res, next)
        } catch(e) {
            console.log(e)
            return res.status(500).send(e)
        }
    },


    async activeRegister (req, res, next) {

        try {
            const where =  { email: req.body.email, activation_token: req.body.password, active: false };
            const user = await User.findOne({
              where: where
            });

            if(user != null){

                await User.update({ active: true, activation_token: '' }, { where: where } );


                let mail = {
                    to: user.email,
                    subject: 'Successful Registration',
                    data: {first_name: user.first_name, email: user.email},
                    template: "successful_registration"
                };
                mailer.sendTemplate(mail);

                return __emailSignin(req, res, next)
            }
            return res.status(500).send({ data: "Email Address does not exist"})
        } catch(e) {
            console.log(e)
            return res.status(500).send(e)
        }
    },


    async passwordCreate (req, res, next) {

        try {
            const where =  { email: req.body.email };
            const user = await User.findOne({
              where: where
            });

            if(user != null){

                await User.update({ activation_token: nanoid() }, { where: where } );


                let mail = {
                    to: user.email,
                    subject: 'Forgot password',
                    data: {first_name: user.first_name, email: user.email},
                    template: "forgot_password"
                };
                mailer.sendTemplate(mail);

                return res.status(200).send({data : "A token has been sent to your email address"})
            }
            return res.status(500).send({ data: "Email Address does not exist"})
        } catch(e) {
            console.log(e)
            return res.status(500).send(e)
        }
    },


    async passwordReset (req, res, next) {

        try {
            const where =  { email: req.body.email, activation_token: req.body.token, active: false };
            const user = await User.findOne({
              where: where
            });

            if(user != null){
                const hashed = await bcrypt.hash(req.body.password, saltRounds)
                await User.update({ password: hashed, activation_token: '' }, { where: where } );
                return __emailSignin(req, res, next)
            }
            return res.status(500).send({ data: "Email Address does not exist"})
        } catch(e) {
            console.log(e)
            return res.status(500).send(e)
        }
    },

    /**
     * Handles user API login
     * @param {*} req
     * @param {*} res
     * @param {*} next
     */
    async apiLogin (req, res, next) {
        const { isValid, error } = validator.validateLogin(req.body)
        if (!isValid) {
            return res.json({error})
        }

        return __signin(req, res, next)
    },

    async socialLogin (req, res) {
        try {
            const user = await User.findOne({
              where: { social_token: req.body.social_token }
            });
            if(user == null){
                const checkEmail = await User.findOne({
                    where: { email: req.body.email }
                });
                if(checkEmail != null){
                    return res.status(500).send({ error : { message: "Email Address already in used"}})
                }
                const body = req.body
                const hashed = await bcrypt.hash(body.social_token, saltRounds)
                const data = {
                    first_name: body.first_name,
                    last_name: body.last_name,
                    email: body.email,
                    phone: body.phone,
                    social_token: body.social_token,
                    active: true,
                    password: hashed
                }
                await User.create(data);
               return __emailSignin(req, res, next)
            }
            return __emailSignin(req, res, next)
        } catch(e) {
            console.log(e)
            return res.status(500).send(e)
        }

    },


}

/**
 * Handles user login
 * @param {*} req Request object
 * @param {*} res Response object
 * @param {*} next Next middleware
 */
async function __signin (req, res, next) {
    /**
     * @TODO Prevent brute force against authentication
     */
    passport.authenticate('login', async (err, user, info) => {
        try {

            if (!user) {
                //console.log(' NO user found')
                return res.status(400).send({
                    ...errorCodes.invalid_email_password
                })
            }
            if (err) {
                //console.log('An Error has Occured')
                const error = new Error('An error occured')
                return next(error)
            }

            req.login(user, { session: false}, async (error) => {

                if (error) return next (error)

                const body = { id: user.id, email: user.email }
                req.user = body
                const token = jwt.sign({ user: body }, config.secretOrKey, {
//                expiresIn: '24h'
                })
                user.password = undefined
                const payload = {
                    data:  user,
                    accessToken: ` ${token}`,
//                    expires_in: '24h'
                }
                return res.json(payload)
            })
        } catch (error) {
            //console.log('__signin ', error)
            return next(error)
        }

    })(req, res, next)
}

async function __emailSignin (req, res, next) {
    /**
     * @TODO Prevent brute force against authentication
     */
    passport.authenticate('emailScreen', async (err, user, info) => {
        try {
            if (!user) {
                //console.log(' NO user found')
                return res.status(400).send({
                    ...errorCodes.invalid_email_password
                })
            }
            if (err) {
                //console.log('An Error has Occured')
                const error = new Error('An error occured')
                return next(error)
            }

            req.login(user, { session: false}, async (error) => {

                if (error) return next (error)

                const body = { id: user.id, email: user.email }
                req.user = body
                const token = jwt.sign({ user: body }, config.secretOrKey, {
//                expiresIn: '24h'
                })
                user.password = undefined
                const payload = {
                    data:  user,
                    accessToken: ` ${token}`,
//                    expires_in: '24h'
                }
                return res.json(payload)
            })
        } catch (error) {
            //console.log('__signin ', error)
            return next(error)
        }

    })(req, res, next)
}


module.exports = UserController