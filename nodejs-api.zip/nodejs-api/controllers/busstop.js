const db = require('../models')
const Busstop = db.sequelize.models.Busstop
const JourneyBusstop = db.sequelize.models.JourneyBusstop
const Op = db.Sequelize.Op;

const BusstopController = {

    async nearestBusstop(req, res) {
        try {
            const lat = req.query.latitude;
            const long = req.query.longitude;
            const busstop = await db.sequelize.query("SELECT * , (3956 * 2 * ASIN(SQRT( POWER(SIN(( "+lat+" - latitude) *  pi()/180 / 2), 2) +COS( "+lat+" * pi()/180) * COS(latitude * pi()/180) * POWER(SIN(( "+long+" - longitude) * pi()/180 / 2), 2) ))) as distance from busstops having  distance <= 10 order by distance");
            return res.status(200).send(busstop)
        } catch(e) {
            console.log('getDepartments ', e)
            return res.status(400).send(e)
        }
    },

    async autoComplete(req, res) {
        try {
            const depts = await Busstop.findAll({
               where: {
                     formatted_address: { [Op.like]: `%`+req.query.busstop+`%` }
               }
           });
            return res.status(200).send(depts)
        } catch(e) {
            console.log('getDepartments ', e)
            return res.status(400).send(e)
        }
    },
    async destinationPoint(req, res) {
        try {

            let array = [];

            const associateBus = await JourneyBusstop.findAll({
                where: { busstop_id: req.params.busstop_id }
            })
            for(var i=0;i< associateBus.length;i++){
                const currentBus = associateBus[i];
                const busstop = await JourneyBusstop.findAll({
                    where: { journey_id: currentBus.journey_id },
                    include : [{ model: Busstop , as: 'busstop'  }]});

                for(var j=0;j< busstop.length;j++){
                    const area = busstop[j];
//                    console.log(area)
                    if (area.position > currentBus.position) {
                        let busstop = area.busstop;

                        array.push({
                            id : busstop.id,
                            longitude : busstop.longitude,
                            latitude : busstop.latitude,
                            address : busstop.address,
                            formatted_address : busstop.formatted_address,
                            journey_id : currentBus.journey_id,
                        })
                    }
                }
            }
            return res.status(200).send(array)
        } catch(e) {
            console.log('getDepartments ', e)
            return res.status(400).send(e)
        }
    },


}

module.exports = BusstopController