const db = require('../models')
const RideTracker = db.sequelize.models.RideTracker;
const User = db.sequelize.models.User;
const RideRequest = db.sequelize.models.RideRequest;
const Busstop = db.sequelize.models.Busstop;
var  publisher = require("redis").createClient();


const RideTrackerController = {


    async create (req, res) {
        try {
            var body = req.body;

           await RideTracker.destroy({
                where: {
                    user_id : req.user.id,
                    passenger_request_id : body.passenger_request_id,
                    driver_request_id : body.driver_request_id,
                    driver_status : "drafted",
                    passenger_status : "approved"
                },
            });

            body.passenger_status = "approved";
            body.driver_status = "drafted";
            body.user_id = req.user.id;
            const createRide = await RideTracker.create(body);


            const ride = await RideTracker.findOne({
                    where: {
                        id: createRide.id,
                    },
                include : [{
                    model: User , as: 'user',
                    attributes: ['id', 'first_name', 'last_name', 'image']
                }, {
                    model: RideRequest , as: 'passengerRequest',
                    include: [{
                        model: User, as: 'user',
                        attributes: ['id', 'first_name', 'last_name', 'image'],
                    },{
                        model: Busstop, as: 'start',
                    },{
                        model: Busstop, as: 'destination',
                    },]
                },
                 {
                    model: RideRequest , as: 'driverRequest',
                    include: [{
                        model: User, as: 'user',
                        attributes: ['id', 'first_name', 'last_name', 'image']
                    },{
                        model: Busstop, as: 'start',
                    },{
                        model: Busstop, as: 'destination',
                    },]
                 }]
            });

            publisher.publish('events.update_driver_ride_tracker_status', JSON.stringify(ride));
            return res.status(200).send(ride)
        } catch (err) {
            console.log(err)
            return res.status(500).send(err)
        }
    },

    async update (req, res) {

        try {
             var createRide = await RideTracker.update(req.body, {
                    where: { id: req.params.rideTracker_id },
                 });


            const ride = await RideTracker.findOne({
                    where: {
                        id: createRide.id,
                    },
                include : [{
                    model: User , as: 'user',
                    attributes: ['id', 'first_name', 'last_name', 'image']
                }, {
                    model: RideRequest , as: 'passengerRequest',
                    include: [{
                        model: User, as: 'user',
                        attributes: ['id', 'first_name', 'last_name', 'image'],
                    },{
                        model: Busstop, as: 'start',
                    },{
                        model: Busstop, as: 'destination',
                    },]
                },
                 {
                    model: RideRequest , as: 'driverRequest',
                    include: [{
                        model: User, as: 'user',
                        attributes: ['id', 'first_name', 'last_name', 'image']
                    },{
                        model: Busstop, as: 'start',
                    },{
                        model: Busstop, as: 'destination',
                    },]
                 }]
            });

            publisher.publish('events.update_ride_tracker_status', JSON.stringify(ride));

            return res.status(200).send(ride)
        } catch (err) {
            console.log(err)
            return res.status(500).send(err)
        }
    },

    async get (req, res) {
        try {
            const ride = await RideTracker.findOne({
                where: { id: req.params.rideTracker_id }
            })
            return res.status(200).send(ride)
        } catch(err) {
            console.log(err)
            return res.status(500).send(err)
        }
    },

    async delete (req, res) {
        try {
            await RideTracker.destroy({
                where: {
                    passenger_request_id: req.query.passenger_request_id,
                    driver_request_id: req.query.driver_request_id,
                }
            })

            return res.status(200).send({data: "It's been deleted"})

        } catch (err) {
            console.log(err)
            return res.status(500).send(err)
        }
    },
}


module.exports = RideTrackerController